library(readxl)
breast_label<-read.table("D://Rdata//breast class label.txt")
breast<-read_xlsx("D://Rdata//breast.xlsx",col_names=F)
breast<-cbind(breast,breast_label)
breast$type<-as.factor(breast$V1)
colname<-colnames(breast)
p=which(colname=="V1")
breast<-breast[,-p]
D<-breast[,-1214]
library(psych)
library(kernlab)#customer kernel svm
library(nloptr)#nonlinear optimization
library(dplyr)
library(splitstackshape)
set.seed(1)
rpca=principal(D,nfactors=16,scores=TRUE,rotate="none")
breastpca<-data.frame(rpca$scores)
breastpca$class<-breast$type

D<-breastpca[,-17]
class=breastpca$class
breastpca1=data.frame(D,class)
#stratified sampling
#set.seed(123)
p0=1;p1=3;p2=3
breastpca_stratified_0.7=stratified(breastpca1,group=c("class"),
                                    size=0.7,replace=F,bothSets=T)
breastpca_train=breastpca_stratified_0.7$SAMP1
breastpca_test=breastpca_stratified_0.7$SAMP2

#custom definiting kernl function
tkernel=function(x,y,w1=0.65,w2=0.35,p=2){
  dist=(sum(abs(x-y)^p))^(1/p)
  v1=0.9918
  f1=(1/(1+dist))^v1;f2=x%*%y
  wf=w1*f1+w2*f2
  return(wf)
}
class(tkernel)="kernel"
#k fold cross-validation
breastpca_p2.5=NULL
seedset=c(12,1:3,6:9,123,1234)
for (seed1 in seedset){
  setseed=seed1
  CV<-function(data=w,Z,seed=setseed){
    set.seed(seed)
    n=nrow(data);N=1:n
    mm=sample(rep(1:Z,ceiling(n/Z))[N])
    K=list()
    for(i in 1:Z) K[[i]]=N[mm==i]
    return(K)
  }
  k=5
  mm=CV(breastpca1,k)
  options(digits=4)
  #svm based p-norm t kernel evaluation
  breastpca.acc<-NULL;breastpca.recall=NULL;breastpca.kappa=NULL
  for (i in 1:k){
    svm_tkernel<-ksvm(class~.,data=breastpca1[-mm[[i]],],
                      kernel=tkernel)
    pred.svm<-predict(svm_tkernel,newdata=breastpca1[mm[[i]],])
    aa<-table(breastpca1[mm[[i]],]$class,pred.svm)
    acc<-(sum(diag(aa)))/sum(aa)
    recall<-(aa[1,1])/sum(aa[1,])
    pe=sum(colSums(aa)*rowSums(aa))/sum(aa)^2
    kappa=(acc-pe)/(1-pe)
    breastpca.acc<-c(breastpca.acc,acc)
    breastpca.recall<-c(breastpca.acc,recall)
    breastpca.kappa<-c(breastpca.kappa,kappa)
  }
  (breastpca_meanacc_tkernel<-mean(breastpca.acc))
  (breastpca_meanrecall_tkernel<-mean(breastpca.recall))
  (breastpca_meankappa_tkernel<-mean(breastpca.kappa))
  tkern=c(breastpca_meanacc_tkernel,breastpca_meanrecall_tkernel,
          breastpca_meankappa_tkernel)
  breastpca_p2.5=cbind(tkern,breastpca_p2.5)
}

#custom definiting kernl function
tkernel=function(x,y,w1=0.65,w2=0.35,p=3){
  dist=(sum(abs(x-y)^p))^(1/p)
  v1=0.9918
  f1=(1/(1+dist))^v1;f2=x%*%y
  wf=w1*f1+w2*f2
  return(wf)
}
class(tkernel)="kernel"
#k fold cross-validation
breastpca_p2=NULL

for (seed1 in seedset){
  setseed=seed1
  CV<-function(data=w,Z,seed=setseed){
    set.seed(seed)
    n=nrow(data);N=1:n
    mm=sample(rep(1:Z,ceiling(n/Z))[N])
    K=list()
    for(i in 1:Z) K[[i]]=N[mm==i]
    return(K)
  }
  k=5
  mm=CV(breastpca1,k)
  options(digits=4)
  #svm based p-norm t kernel evaluation
  breastpca.acc<-NULL;breastpca.recall=NULL;breastpca.kappa=NULL
  for (i in 1:k){
    svm_tkernel<-ksvm(class~.,data=breastpca1[-mm[[i]],],
                      kernel=tkernel)
    pred.svm<-predict(svm_tkernel,newdata=breastpca1[mm[[i]],])
    aa<-table(breastpca1[mm[[i]],]$class,pred.svm)
    acc<-(sum(diag(aa)))/sum(aa)
    recall<-(aa[1,1])/sum(aa[1,])
    pe=sum(colSums(aa)*rowSums(aa))/sum(aa)^2
    kappa=(acc-pe)/(1-pe)
    breastpca.acc<-c(breastpca.acc,acc)
    breastpca.recall<-c(breastpca.acc,recall)
    breastpca.kappa<-c(breastpca.kappa,kappa)
  }
  (breastpca_meanacc_tkernel<-mean(breastpca.acc))
  (breastpca_meanrecall_tkernel<-mean(breastpca.recall))
  (breastpca_meankappa_tkernel<-mean(breastpca.kappa))
  tkern=c(breastpca_meanacc_tkernel,breastpca_meanrecall_tkernel,
          breastpca_meankappa_tkernel)
  breastpca_p2=cbind(tkern,breastpca_p2)
}

rownames(breastpca_p2.5)=c("accuracy","recall","kappa")
d_acc=breastpca_p2.5[1,]-breastpca_p2[1,]
sacc=sqrt(var(d_acc));n=sqrt(10)
(tacc=mean(d_acc)/(sacc/n))
mean(breastpca_p2.5[1,])-mean(breastpca_p2[1,])

d_recall=breastpca_p2.5[2,]-breastpca_p2[2,]
srecall=sqrt(var(d_recall));n=sqrt(10)
(trecall=mean(d_recall)/(srecall/n))
mean(breastpca_p2.5[2,])-mean(breastpca_p2[2,])

d_kappa=breastpca_p2.5[3,]-breastpca_p2[3,]
skappa=sqrt(var(d_kappa));n=sqrt(10)
(tkappa=mean(d_kappa)/(skappa/n))
mean(breastpca_p2.5[3,])-mean(breastpca_p2[3,])

