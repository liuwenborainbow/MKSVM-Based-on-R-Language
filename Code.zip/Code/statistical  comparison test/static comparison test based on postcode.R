library(kernlab)#customer kernel svm
library(nloptr)#nonlinear optimization
library(dplyr)
library(splitstackshape)
set.seed(1)
postcode=read.table("D://Rdata2//postcode.txt", sep="",header=F)
postcode$class=as.factor(postcode$V1)
postcode=postcode[,-1]
D<-postcode[,-257]

#stratified sampling 
p0=1;p1=3;p2=3
postcode_stratified=stratified(postcode,group=c("class"),
                               size=0.1,replace=F,bothSets=T)
postcode_train=postcode_stratified$SAMP1
postcode_test=postcode_stratified$SAMP2
postcode1=postcode_train

#comparison experiment based different kernel
#custom definiting kernl function
tkernel=function(x,y,w1=0.86,w2=0.14,p=1.5){
  dist=(sum(abs(x-y)^p))^(1/p)
  v1=0.84
  f1=(1/(1+dist))^v1;f2=x%*%y
  wf=w1*f1+w2*f2
  return(wf)
}
class(tkernel)="kernel"
#k fold cross-validation
postcode_p1.5=NULL
seedset=c(12,1:9)
for (seed1 in seedset){
  setseed=seed1
  CV<-function(data=w,Z,seed=setseed){
    set.seed(seed)
    n=nrow(data);N=1:n
    mm=sample(rep(1:Z,ceiling(n/Z))[N])
    K=list()
    for(i in 1:Z) K[[i]]=N[mm==i]
    return(K)
  }
  k=5
  mm=CV(postcode1,k)
  options(digits=4)
  #svm based p-norm t kernel evaluation
  postcode.acc<-NULL;postcode.recall=NULL;postcode.kappa=NULL
  for (i in 1:k){
    svm_tkernel<-ksvm(class~.,data=postcode1[-mm[[i]],],
                      kernel=tkernel)
    pred.svm<-predict(svm_tkernel,newdata=postcode1[mm[[i]],])
    aa<-table(postcode1[mm[[i]],]$class,pred.svm)
    acc<-(sum(diag(aa)))/sum(aa)
    recall<-(aa[1,1])/sum(aa[1,])
    pe=sum(colSums(aa)*rowSums(aa))/sum(aa)^2
    kappa=(acc-pe)/(1-pe)
    postcode.acc<-c(postcode.acc,acc)
    postcode.recall<-c(postcode.acc,recall)
    postcode.kappa<-c(postcode.kappa,kappa)
  }
  (postcode_meanacc_tkernel<-mean(postcode.acc))
  (postcode_meanrecall_tkernel<-mean(postcode.recall))
  (postcode_meankappa_tkernel<-mean(postcode.kappa))
  tkern=c(postcode_meanacc_tkernel,postcode_meanrecall_tkernel,
          postcode_meankappa_tkernel)
  postcode_p1.5=cbind(tkern,postcode_p1.5)
}
#2nd team
tkernel=function(x,y,w1=0.86,w2=0.14,p=4){
  dist=(sum(abs(x-y)^p))^(1/p)
  v1=0.84
  f1=(1/(1+dist))^v1;f2=x%*%y
  wf=w1*f1+w2*f2
  return(wf)
}
class(tkernel)="kernel"
#k fold cross-validation
postcode_p2=NULL
seedset=c(12,1:9)
for (seed1 in seedset){
  setseed=seed1
  CV<-function(data=w,Z,seed=setseed){
    set.seed(seed)
    n=nrow(data);N=1:n
    mm=sample(rep(1:Z,ceiling(n/Z))[N])
    K=list()
    for(i in 1:Z) K[[i]]=N[mm==i]
    return(K)
  }
  k=5
  mm=CV(postcode1,k)
  options(digits=4)
  #svm based p-norm t kernel evaluation
  postcode.acc<-NULL;postcode.recall=NULL;postcode.kappa=NULL
  for (i in 1:k){
    svm_tkernel<-ksvm(class~.,data=postcode1[-mm[[i]],],
                      kernel=tkernel)
    pred.svm<-predict(svm_tkernel,newdata=postcode1[mm[[i]],])
    aa<-table(postcode1[mm[[i]],]$class,pred.svm)
    acc<-(sum(diag(aa)))/sum(aa)
    recall<-(aa[1,1])/sum(aa[1,])
    pe=sum(colSums(aa)*rowSums(aa))/sum(aa)^2
    kappa=(acc-pe)/(1-pe)
    postcode.acc<-c(postcode.acc,acc)
    postcode.recall<-c(postcode.acc,recall)
    postcode.kappa<-c(postcode.kappa,kappa)
  }
  (postcode_meanacc_tkernel<-mean(postcode.acc))
  (postcode_meanrecall_tkernel<-mean(postcode.recall))
  (postcode_meankappa_tkernel<-mean(postcode.kappa))
  tkern=c(postcode_meanacc_tkernel,postcode_meanrecall_tkernel,
          postcode_meankappa_tkernel)
  postcode_p2=cbind(tkern,postcode_p2)
}
rownames(postcode_p1.5)=c("accuracy","recall","kappa")
d_acc=postcode_p1.5[1,]-postcode_p2[1,]
sacc=sqrt(var(d_acc));n=sqrt(10)
(tacc=mean(d_acc)/(sacc/n))
mean(postcode_p1.5[1,])-mean(postcode_p2[1,])

d_recall=postcode_p1.5[2,]-postcode_p2[2,]
srecall=sqrt(var(d_recall));n=sqrt(10)
(trecall=mean(d_recall)/(srecall/n))
mean(postcode_p1.5[2,])-mean(postcode_p2[2,])

d_kappa=postcode_p1.5[3,]-postcode_p2[3,]
skappa=sqrt(var(d_kappa));n=sqrt(10)
(tkappa=mean(d_kappa)/(skappa/n))
mean(postcode_p1.5[3,])-mean(postcode_p2[3,])




