library(kernlab)#customer kernel svm
library(nloptr)#nonlinear optimization
library(dplyr)
library(splitstackshape)
set.seed(1)
derm=read.csv("D://Rdata2//derm.csv")
D<-derm[,-35]

class=as.factor(derm$V35)
derm1=data.frame(D,class)
#stratified sampling
#set.seed(123)
p0=1;p1=3;p2=2
derm_stratified_0.7=stratified(derm1,group=c("class"),
                               size=0.7,replace=F,bothSets=T)
derm_train=derm_stratified_0.7$SAMP1
derm_test=derm_stratified_0.7$SAMP2


#custom definiting kernl function
tkernel=function(x,y,w1=0.23,w2=0.77,p=1){
  dist=(sum(abs(x-y)^p))^(1/p)
  v1=0.9437;v2=0.69;gamma=0.01; dist1=(sum(abs(x-y)^2))^(1/2)
  f1=(1/(1+dist))^v1;f2=exp(-gamma*(dist1^2))
  wf=w1*f1+w2*f2
  return(wf)
}
class(tkernel)="kernel"
derm_p1.5=NULL
seedset=c(12,1:9)
for (seed1 in seedset){
  setseed=seed1
  CV<-function(data=w,Z,seed=setseed){
    set.seed(seed)
    n=nrow(data);N=1:n
    mm=sample(rep(1:Z,ceiling(n/Z))[N])
    K=list()
    for(i in 1:Z) K[[i]]=N[mm==i]
    return(K)
  }
  k=5
  mm=CV(derm1,k)
  options(digits=4)
  #svm based p-norm t kernel evaluation
  derm.acc<-NULL;derm.recall=NULL;derm.kappa=NULL
  for (i in 1:k){
    svm_tkernel<-ksvm(class~.,data=derm1[-mm[[i]],],
                      kernel=tkernel)
    pred.svm<-predict(svm_tkernel,newdata=derm1[mm[[i]],])
    aa<-table(derm1[mm[[i]],]$class,pred.svm)
    acc<-(sum(diag(aa)))/sum(aa)
    recall<-(aa[1,1])/sum(aa[1,])
    pe=sum(colSums(aa)*rowSums(aa))/sum(aa)^2
    kappa=(acc-pe)/(1-pe)
    derm.acc<-c(derm.acc,acc)
    derm.recall<-c(derm.acc,recall)
    derm.kappa<-c(derm.kappa,kappa)
  }
  (derm_meanacc_tkernel<-mean(derm.acc))
  (derm_meanrecall_tkernel<-mean(derm.recall))
  (derm_meankappa_tkernel<-mean(derm.kappa))
  tkern=c(derm_meanacc_tkernel,derm_meanrecall_tkernel,
          derm_meankappa_tkernel)
  derm_p1.5=cbind(tkern,derm_p1.5)
}

#2nd team
tkernel=function(x,y,w1=0.23,w2=0.77,p=2){
  dist=(sum(abs(x-y)^p))^(1/p)
  v1=0.9437;v2=0.69;gamma=0.01; dist1=(sum(abs(x-y)^2))^(1/2)
  f1=(1/(1+dist))^v1;f2=exp(-gamma*(dist1^2))
  wf=w1*f1+w2*f2
  return(wf)
}
class(tkernel)="kernel"
derm_p2=NULL
seedset=c(12,1:9)
for (seed1 in seedset){
  setseed=seed1
  CV<-function(data=w,Z,seed=setseed){
    set.seed(seed)
    n=nrow(data);N=1:n
    mm=sample(rep(1:Z,ceiling(n/Z))[N])
    K=list()
    for(i in 1:Z) K[[i]]=N[mm==i]
    return(K)
  }
  k=5
  mm=CV(derm1,k)
  options(digits=4)
  #svm based p-norm t kernel evaluation
  derm.acc<-NULL;derm.recall=NULL;derm.kappa=NULL
  for (i in 1:k){
    svm_tkernel<-ksvm(class~.,data=derm1[-mm[[i]],],
                      kernel=tkernel)
    pred.svm<-predict(svm_tkernel,newdata=derm1[mm[[i]],])
    aa<-table(derm1[mm[[i]],]$class,pred.svm)
    acc<-(sum(diag(aa)))/sum(aa)
    recall<-(aa[1,1])/sum(aa[1,])
    pe=sum(colSums(aa)*rowSums(aa))/sum(aa)^2
    kappa=(acc-pe)/(1-pe)
    derm.acc<-c(derm.acc,acc)
    derm.recall<-c(derm.acc,recall)
    derm.kappa<-c(derm.kappa,kappa)
  }
  (derm_meanacc_tkernel<-mean(derm.acc))
  (derm_meanrecall_tkernel<-mean(derm.recall))
  (derm_meankappa_tkernel<-mean(derm.kappa))
  tkern=c(derm_meanacc_tkernel,derm_meanrecall_tkernel,
          derm_meankappa_tkernel)
  derm_p2=cbind(tkern,derm_p2)
}

rownames(derm_p1.5)=c("accuracy","recall","kappa")
d_acc=derm_p1.5[1,]-derm_p2[1,]
sacc=sqrt(var(d_acc));n=sqrt(10)
(tacc=mean(d_acc)/(sacc/n))
mean(derm_p1.5[1,])-mean(derm_p2[1,])

d_recall=derm_p1.5[2,]-derm_p2[2,]
srecall=sqrt(var(d_recall));n=sqrt(10)
(trecall=mean(d_recall)/(srecall/n))
mean(derm_p1.5[2,])-mean(derm_p2[2,])

d_kappa=derm_p1.5[3,]-derm_p2[3,]
skappa=sqrt(var(d_kappa));n=sqrt(10)
(tkappa=mean(d_kappa)/(skappa/n))
mean(derm_p1.5[3,])-mean(derm_p2[3,])


