library(kernlab)#customer kernel svm
library(nloptr)#nonlinear optimization
library(dplyr)
library(splitstackshape)
set.seed(1)
pima=read.table("D://Rdata//pima.txt", sep="",header=T)
pima$type=as.factor(pima$type)
D<-pima[,-9]
class=pima$type
pima1=data.frame(D,class)
#stratified sampling
#set.seed(123)
p0=1;p1=3;p2=3
pima_stratified_0.7=stratified(pima1,group=c("class"),
                               size=0.7,replace=F,bothSets=T)
pima_train=pima_stratified_0.7$SAMP1
pima_test=pima_stratified_0.7$SAMP2


#comparison experiment based different kernel
#custom definiting kernl function
tkernel=function(x,y,w1=0.78,w2=0.22,p=2){
  dist=(sum(abs(x-y)^p))^(1/p)
  v1=0.90725;v2=0.85869
  f1=(1/(1+dist))^v1;f2=(1/(1+dist))^v1
  wf=w1*f1+w2*f2
  return(wf)
}
class(tkernel)="kernel"
#k fold cross-validation
#setseed=12 123 1234 12345 123456
pima_p2=NULL
seedset=c(12,1:9)
for (seed1 in seedset){
  setseed=seed1
  CV<-function(data=w,Z,seed=setseed){
    set.seed(seed)
    n=nrow(data);N=1:n
    mm=sample(rep(1:Z,ceiling(n/Z))[N])
    K=list()
    for(i in 1:Z) K[[i]]=N[mm==i]
    return(K)
  }
  k=5
  mm=CV(pima1,k)
  options(digits=4)
  #svm based p-norm t kernel evaluation
  pima.acc<-NULL;pima.recall=NULL;pima.kappa=NULL
  for (i in 1:k){
    svm_tkernel<-ksvm(class~.,data=pima1[-mm[[i]],],
                      kernel=tkernel)
    pred.svm<-predict(svm_tkernel,newdata=pima1[mm[[i]],])
    aa<-table(pima1[mm[[i]],]$class,pred.svm)
    acc<-(sum(diag(aa)))/sum(aa)
    recall<-(aa[1,1])/sum(aa[1,])
    pe=sum(colSums(aa)*rowSums(aa))/sum(aa)^2
    kappa=(acc-pe)/(1-pe)
    pima.acc<-c(pima.acc,acc)
    pima.recall<-c(pima.acc,recall)
    pima.kappa<-c(pima.kappa,kappa)
  }
  (pima_meanacc_tkernel<-mean(pima.acc))
  (pima_meanrecall_tkernel<-mean(pima.recall))
  (pima_meankappa_tkernel<-mean(pima.kappa))
  tkern=c(pima_meanacc_tkernel,pima_meanrecall_tkernel,
          pima_meankappa_tkernel)
  pima_p2=cbind(tkern,pima_p2)
  
}
rownames(pima_p2)=c("accuracy","recall","kappa")

tkernel=function(x,y,w1=0.78,w2=0.22,p=3){
  dist=(sum(abs(x-y)^p))^(1/p)
  v1=0.90725;v2=0.85869
  f1=(1/(1+dist))^v1;f2=(1/(1+dist))^v1
  wf=w1*f1+w2*f2
  return(wf)
}
class(tkernel)="kernel"
#k fold cross-validation
#setseed=12 123 1234 12345 123456
pima_p1.5=NULL
seedset=c(12,1:9)
for (seed1 in seedset){
  setseed=seed1
  CV<-function(data=w,Z,seed=setseed){
    set.seed(seed)
    n=nrow(data);N=1:n
    mm=sample(rep(1:Z,ceiling(n/Z))[N])
    K=list()
    for(i in 1:Z) K[[i]]=N[mm==i]
    return(K)
  }
  k=5
  mm=CV(pima1,k)
  options(digits=4)
  #svm based p-norm t kernel evaluation
  pima.acc<-NULL;pima.recall=NULL;pima.kappa=NULL
  for (i in 1:k){
    svm_tkernel<-ksvm(class~.,data=pima1[-mm[[i]],],
                      kernel=tkernel)
    pred.svm<-predict(svm_tkernel,newdata=pima1[mm[[i]],])
    aa<-table(pima1[mm[[i]],]$class,pred.svm)
    acc<-(sum(diag(aa)))/sum(aa)
    recall<-(aa[1,1])/sum(aa[1,])
    pe=sum(colSums(aa)*rowSums(aa))/sum(aa)^2
    kappa=(acc-pe)/(1-pe)
    pima.acc<-c(pima.acc,acc)
    pima.recall<-c(pima.acc,recall)
    pima.kappa<-c(pima.kappa,kappa)
  }
  (pima_meanacc_tkernel<-mean(pima.acc))
  (pima_meanrecall_tkernel<-mean(pima.recall))
  (pima_meankappa_tkernel<-mean(pima.kappa))
  tkern=c(pima_meanacc_tkernel,pima_meanrecall_tkernel,
          pima_meankappa_tkernel)
  pima_p1.5=cbind(tkern,pima_p1.5)
  
}
rownames(pima_p1.5)=c("accuracy","recall","kappa")
d_acc=pima_p1.5[1,]-pima_p2[1,]
sacc=sqrt(var(d_acc));n=sqrt(10)
(tacc=mean(d_acc)/(sacc/n))
mean(pima_p1.5[1,])-mean(pima_p2[1,])

d_recall=pima_p1.5[2,]-pima_p2[2,]
srecall=sqrt(var(d_recall));n=sqrt(10)
(trecall=mean(d_recall)/(srecall/n))
mean(pima_p1.5[2,])-mean(pima_p2[2,])

d_kappa=pima_p1.5[3,]-pima_p2[3,]
skappa=sqrt(var(d_kappa));n=sqrt(10)
(tkappa=mean(d_kappa)/(skappa/n))
mean(pima_p1.5[3,])-mean(pima_p2[3,])


