library(kernlab)#customer kernel svm
library(nloptr)#nonlinear optimization
library(dplyr)
library(splitstackshape)
set.seed(1)
kidney=read.csv("D://Rdata2//kidney02.csv")
D<-kidney[,-25]
D$rbc=as.numeric(D$rbc)
D$pc=as.numeric(D$pc)
D$pcc=as.numeric(D$pcc)
D$ba=as.numeric(D$ba)
D$htn=as.numeric(D$htn)
D$dm=as.numeric(D$dm)
D$cad=as.numeric(D$cad)
D$appet=as.numeric(D$appet)
D$pe=as.numeric(D$pe)
D$ane=as.numeric(D$ane)
D<-as.data.frame(scale(D))
class=kidney$class
kidney1=data.frame(D,class)

#stratified sampling
#set.seed(123)
p0=1;p1=3;p2=2;v1=5.16;v2=0.8
kidney_stratified_0.7=stratified(kidney1,group=c("class"),
                                 size=0.7,replace=F,bothSets=T)
kidney_train=kidney_stratified_0.7$SAMP1
kidney_test=kidney_stratified_0.7$SAMP2


#custom definiting kernl function
tkernel=function(x,y,w1=0.78,w2=0.22,p1=1.5,p2=1.5){
  dist1=(sum(abs(x-y)^p1))^p1
  dist2=(sum(abs(x-y)^p2))^p2
  v1=1;v2=0.8
  f1=(1/(1+dist1))^v1;f2=(1/(1+dist2))^v2
  wf=w1*f1+w2*f2
  return(wf)
}
class(tkernel)="kernel"
#k fold cross-validation
kidney_p1.5=NULL
seedset=c(12,1:9)
for (seed1 in seedset){
  setseed=seed1
  CV<-function(data=w,Z,seed=setseed){
    set.seed(seed)
    n=nrow(data);N=1:n
    mm=sample(rep(1:Z,ceiling(n/Z))[N])
    K=list()
    for(i in 1:Z) K[[i]]=N[mm==i]
    return(K)
  }
  k=5
  mm=CV(kidney1,k)
  #svm based p-norm t kernel evaluation
  kidney.acc<-NULL;kidney.recall=NULL;kidney.kappa=NULL
  for (i in 1:k){
    svm_tkernel<-ksvm(class~.,data=kidney1[-mm[[i]],],
                      kernel=tkernel)
    pred.svm<-predict(svm_tkernel,newdata=kidney1[mm[[i]],])
    aa<-table(kidney1[mm[[i]],]$class,pred.svm)
    acc<-(sum(diag(aa)))/sum(aa)
    recall<-(aa[1,1])/sum(aa[1,])
    pe=sum(colSums(aa)*rowSums(aa))/sum(aa)^2
    kappa=(acc-pe)/(1-pe)
    kidney.acc<-c(kidney.acc,acc)
    kidney.recall<-c(kidney.acc,recall)
    kidney.kappa<-c(kidney.kappa,kappa)
  }
  (kidney_meanacc_tkernel<-mean(kidney.acc))
  (kidney_meanrecall_tkernel<-mean(kidney.recall))
  (kidney_meankappa_tkernel<-mean(kidney.kappa))
  tkern=c(kidney_meanacc_tkernel,kidney_meanrecall_tkernel,
          kidney_meankappa_tkernel)
  kidney_p1.5=cbind(tkern,kidney_p1.5)
}

#2nd team
tkernel=function(x,y,w1=0.78,w2=0.22,p1=2,p2=2){
  dist1=(sum(abs(x-y)^p1))^p1
  dist2=(sum(abs(x-y)^p2))^p2
  v1=1;v2=0.8
  f1=(1/(1+dist1))^v1;f2=(1/(1+dist2))^v2
  wf=w1*f1+w2*f2
  return(wf)
}
class(tkernel)="kernel"
#k fold cross-validation
kidney_p2=NULL
seedset=c(12,1:9)
for (seed1 in seedset){
  setseed=seed1
  CV<-function(data=w,Z,seed=setseed){
    set.seed(seed)
    n=nrow(data);N=1:n
    mm=sample(rep(1:Z,ceiling(n/Z))[N])
    K=list()
    for(i in 1:Z) K[[i]]=N[mm==i]
    return(K)
  }
  k=5
  mm=CV(kidney1,k)
  #svm based p-norm t kernel evaluation
  kidney.acc<-NULL;kidney.recall=NULL;kidney.kappa=NULL
  for (i in 1:k){
    svm_tkernel<-ksvm(class~.,data=kidney1[-mm[[i]],],
                      kernel=tkernel)
    pred.svm<-predict(svm_tkernel,newdata=kidney1[mm[[i]],])
    aa<-table(kidney1[mm[[i]],]$class,pred.svm)
    acc<-(sum(diag(aa)))/sum(aa)
    recall<-(aa[1,1])/sum(aa[1,])
    pe=sum(colSums(aa)*rowSums(aa))/sum(aa)^2
    kappa=(acc-pe)/(1-pe)
    kidney.acc<-c(kidney.acc,acc)
    kidney.recall<-c(kidney.acc,recall)
    kidney.kappa<-c(kidney.kappa,kappa)
  }
  (kidney_meanacc_tkernel<-mean(kidney.acc))
  (kidney_meanrecall_tkernel<-mean(kidney.recall))
  (kidney_meankappa_tkernel<-mean(kidney.kappa))
  tkern=c(kidney_meanacc_tkernel,kidney_meanrecall_tkernel,
          kidney_meankappa_tkernel)
  kidney_p2=cbind(tkern,kidney_p2)
}
rownames(kidney_p1.5)=c("accuracy","recall","kappa")
d_acc=kidney_p1.5[1,]-kidney_p2[1,]
sacc=sqrt(var(d_acc));n=sqrt(10)
(tacc=mean(d_acc)/(sacc/n))
mean(kidney_p1.5[1,])-mean(kidney_p2[1,])

d_recall=kidney_p1.5[2,]-kidney_p2[2,]
srecall=sqrt(var(d_recall));n=sqrt(10)
(trecall=mean(d_recall)/(srecall/n))
mean(kidney_p1.5[2,])-mean(kidney_p2[2,])

d_kappa=kidney_p1.5[3,]-kidney_p2[3,]
skappa=sqrt(var(d_kappa));n=sqrt(10)
(tkappa=mean(d_kappa)/(skappa/n))
mean(kidney_p1.5[3,])-mean(kidney_p2[3,])
