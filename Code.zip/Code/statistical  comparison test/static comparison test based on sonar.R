rm(list=ls())
library(readxl)
library(kernlab)#customer kernel svm
library(nloptr)#nonlinear optimization
library(dplyr)
library(splitstackshape)
set.seed(1)
sonar=read.table("D://Rdata//sonar.txt", sep=",",header=F)
sonar$class=sonar$V61
sonar=sonar[,-61]
D<-sonar[,-61]
sonar1=sonar
#stratified sampling
#set.seed(123)
p0=1;p1=3;p2=3
sonar_stratified_0.7=stratified(sonar,group=c("class"),
                                size=0.8,replace=F,bothSets=T)
sonar_train=sonar_stratified_0.7$SAMP1
sonar_test=sonar_stratified_0.7$SAMP2


#custom definiting kernl function
tkernel=function(x,y,w1=0.71,w2=0.29,p=2){
  dist=(sum(abs(x-y)^p))^(1/p)
  dist1=(sum(abs(x-y)^2))^(1/2)
  v1=0.94;v2=0.771;gamma=0.044
  f1=(1/(1+dist))^v1;f2=exp(-gamma*(dist1^2))
  wf=w1*f1+w2*f2
  return(wf)
}
class(tkernel)="kernel"
#k fold cross-validation
#setseed=12 123 1234 12345 123456
sonar_p2=NULL
seedset=c(12,1:9)
for (seed1 in seedset){
  setseed=seed1
  CV<-function(data=w,Z,seed=setseed){
    set.seed(seed)
    n=nrow(data);N=1:n
    mm=sample(rep(1:Z,ceiling(n/Z))[N])
    K=list()
    for(i in 1:Z) K[[i]]=N[mm==i]
    return(K)
  }
  k=5
  mm=CV(sonar1,k)
  options(digits=4)
  #svm based p-norm t kernel evaluation
  sonar.acc<-NULL;sonar.recall=NULL;sonar.kappa=NULL
  for (i in 1:k){
    svm_tkernel<-ksvm(class~.,data=sonar1[-mm[[i]],],
                      kernel=tkernel)
    pred.svm<-predict(svm_tkernel,newdata=sonar1[mm[[i]],])
    aa<-table(sonar1[mm[[i]],]$class,pred.svm)
    acc<-(sum(diag(aa)))/sum(aa)
    recall<-(aa[1,1])/sum(aa[1,])
    pe=sum(colSums(aa)*rowSums(aa))/sum(aa)^2
    kappa=(acc-pe)/(1-pe)
    sonar.acc<-c(sonar.acc,acc)
    sonar.recall<-c(sonar.acc,recall)
    sonar.kappa<-c(sonar.kappa,kappa)
  }
  (sonar_meanacc_tkernel<-mean(sonar.acc))
  (sonar_meanrecall_tkernel<-mean(sonar.recall))
  (sonar_meankappa_tkernel<-mean(sonar.kappa))
  tkern=c(sonar_meanacc_tkernel,sonar_meanrecall_tkernel,
          sonar_meankappa_tkernel)
  sonar_p2=cbind(tkern,sonar_p2)
    
}
rownames(sonar_p2)=c("accuracy","recall","kappa")

tkernel=function(x,y,w1=0.71,w2=0.29,p=1.5){
  dist=(sum(abs(x-y)^p))^(1/p)
  dist1=(sum(abs(x-y)^2))^(1/2)
  v1=0.94;v2=0.771;gamma=0.044
  f1=(1/(1+dist))^v1;f2=exp(-gamma*(dist1^2))
  wf=w1*f1+w2*f2
  return(wf)
}
class(tkernel)="kernel"
#k fold cross-validation
#setseed=12 123 1234 12345 123456
sonar_p1.5=NULL
seedset=c(12,1:9)
for (seed1 in seedset){
  setseed=seed1
  CV<-function(data=w,Z,seed=setseed){
    set.seed(seed)
    n=nrow(data);N=1:n
    mm=sample(rep(1:Z,ceiling(n/Z))[N])
    K=list()
    for(i in 1:Z) K[[i]]=N[mm==i]
    return(K)
  }
  k=5
  mm=CV(sonar1,k)
  options(digits=4)
  #svm based p-norm t kernel evaluation
  sonar.acc<-NULL;sonar.recall=NULL;sonar.kappa=NULL
  for (i in 1:k){
    svm_tkernel<-ksvm(class~.,data=sonar1[-mm[[i]],],
                      kernel=tkernel)
    pred.svm<-predict(svm_tkernel,newdata=sonar1[mm[[i]],])
    aa<-table(sonar1[mm[[i]],]$class,pred.svm)
    acc<-(sum(diag(aa)))/sum(aa)
    recall<-(aa[1,1])/sum(aa[1,])
    pe=sum(colSums(aa)*rowSums(aa))/sum(aa)^2
    kappa=(acc-pe)/(1-pe)
    sonar.acc<-c(sonar.acc,acc)
    sonar.recall<-c(sonar.acc,recall)
    sonar.kappa<-c(sonar.kappa,kappa)
  }
  (sonar_meanacc_tkernel<-mean(sonar.acc))
  (sonar_meanrecall_tkernel<-mean(sonar.recall))
  (sonar_meankappa_tkernel<-mean(sonar.kappa))
  tkern=c(sonar_meanacc_tkernel,sonar_meanrecall_tkernel,
          sonar_meankappa_tkernel)
  sonar_p1.5=cbind(tkern,sonar_p1.5)
  
}
rownames(sonar_p1.5)=c("accuracy","recall","kappa")

d_acc=sonar_p1.5[1,]-sonar_p2[1,]
sacc=sqrt(var(d_acc));n=sqrt(10)
(tacc=mean(d_acc)/(sacc/n))
mean(sonar_p1.5[1,])-mean(sonar_p2[1,])

d_recall=sonar_p1.5[2,]-sonar_p2[2,]
srecall=sqrt(var(d_recall));n=sqrt(10)
(trecall=mean(d_recall)/(srecall/n))
mean(sonar_p1.5[2,])-mean(sonar_p2[2,])

d_kappa=sonar_p1.5[3,]-sonar_p2[3,]
skappa=sqrt(var(d_kappa));n=sqrt(10)
(tkappa=mean(d_kappa)/(skappa/n))
mean(sonar_p1.5[3,])-mean(sonar_p2[3,])


