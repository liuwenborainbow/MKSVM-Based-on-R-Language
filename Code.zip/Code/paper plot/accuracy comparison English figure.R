library(ggplot2)
library(readxl)
result=read_xlsx("D://Rdata//p-norm t kernel result.xlsx")
result=as.data.frame(result)
result$data=as.factor(result$data)
a=expression(paste(italic(p),"-norm Distance"))
ggplot(data=result, aes(x=pnorm,y=accuracy,shape=data,
                        col=data))+
  geom_line(size=0.4)+
  geom_point(size=1.2)+
  labs(x=a, y="Accuracy",col="Data",shape="Data")+
  theme(panel.background=element_rect(fill="white",
                                      colour="black"))
ggsave("D://p-norm acc result.tiff", width=6,height=3)

ggplot(data=result, aes(x=pnorm,y=recall,shape=data,
                        col=data))+
  geom_line(size=0.4)+
  geom_point(size=1.2)+
  labs(x=a, y="Recall",col="Data",shape="Data")+
  theme(panel.background=element_rect(fill="white",
                                      colour="black"))
ggsave("D://p-norm recall result.tiff", width=6,height=3)

ggplot(data=result,aes(x=pnorm,y=kappa,shape=data,
                        col=data))+
  geom_line(size=0.4)+
  geom_point(size=1.2)+
  labs(x=a, y="Kappa Coefficient",col="Data",
       shape="Data")+
  theme(panel.background=element_rect(fill="white",
                                      colour="black"))
ggsave("D://p-norm recall kappa result.tiff", width=6,height=3)