library(ggplot2)
library(readxl)
result=read_xlsx("D://Rdata//p-norm t kernel result.xlsx")
result=as.data.frame(result)
result$data=as.factor(result$data)
a=expression(paste(italic(p),"-��������"))
ggplot(data=result, aes(x=pnorm,y=accuracy,shape=data,
                        col=data))+
  geom_line(size=0.4)+
  geom_point(size=1.2)+
  labs(x=a, y="����",col="���ݼ�",shape="���ݼ�")+
  theme(panel.background=element_rect(fill="white",
                                      colour="black"))
ggsave("D://p-norm acc result.tiff", width=6,height=3)

ggplot(data=result, aes(x=pnorm,y=recall,shape=data,
                        col=data))+
  geom_line(size=0.4)+
  geom_point(size=1.2)+
  labs(x=a, y="��ȫ��",col="���ݼ�",shape="���ݼ�")+
  theme(panel.background=element_rect(fill="white",
                                      colour="black"))
ggsave("D://p-norm recall result.tiff", width=6,height=3)

ggplot(data=result,aes(x=pnorm,y=kappa,shape=data,
                        col=data))+
  geom_line(size=0.4)+
  geom_point(size=1.2)+
  labs(x=a, y="Kappaϵ��",col="���ݼ�",
       shape="���ݼ�")+
  theme(panel.background=element_rect(fill="white",
                                      colour="black"))
ggsave("D://p-norm recall kappa result.tiff", width=6,height=3)