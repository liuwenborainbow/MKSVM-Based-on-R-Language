library(kernlab)#customer kernel svm
library(nloptr)#nonlinear optimization
library(dplyr)
library(splitstackshape)
set.seed(1)
postcode=read.table("D://Rdata2//postcode.txt", sep="",header=F)

postcode$class=as.factor(postcode$V1)
postcode=postcode[,-1]
D<-postcode[,-257]

#stratified sampling
#set.seed(123)
p0=1;p1=3;p2=3
postcode_stratified=stratified(postcode,group=c("class"),
                               size=0.1,replace=F,bothSets=T)
postcode_train=postcode_stratified$SAMP1
postcode_test=postcode_stratified$SAMP2
postcode1=postcode_train
#kernel parameters optimazation
generate_labelmatrix=function(y){
  Y=numeric();k=0#y is colnum vector
  for(i in 1:nrow(y)){
    for(j in 1:nrow(y)){
      k=k+1
      if(y[i]==y[j])
        Y[k]=1
      else Y[k]=-1
    }
  }
  labelmatrix=matrix(Y,nrow=nrow(y))
  return(labelmatrix)
}
yy=as.numeric(postcode_train$class)
yy=matrix(yy,ncol=1)
postcode.YY=generate_labelmatrix(yy)

#definiting the affinity matrix
affinity_mat=function(distmat,ymat){
  A=numeric();k=0
  for(i in 1:nrow(ymat)){
    for(j in 1:ncol(ymat)){
      k=k+1
      if(ymat[i,j]==1){
        A[k]=1/(1+distmat[i,j]^2) 
      } else{
        A[k]=1
      }
    }
  }
  affinity_matrix=matrix(A,nrow=nrow(ymat),ncol=ncol(ymat),byrow=T)
  return(affinity_matrix)
}
Dist=dist(postcode_train[,-257],"minkowski",p=p0,upper=T,diag=T)
Dist=as.matrix(Dist)
A=affinity_mat(distmat=Dist,ymat=postcode.YY)
D1=dist(postcode_train[,-257],"minkowski",p=p1,upper=T,diag=T)
D1=as.matrix(D1)
D2=dist(postcode_train[,-257],"minkowski",p=p2,upper=T,diag=T)
D2=as.matrix(D2)
K1=(1/(1+D1));K2=(1/(1+D2))
#bulid objective function
ff<-function(w){
  w1=w[1];w2=w[2];v1=w[3];v2=w[4]
  f=-sum(A*postcode.YY*(w1*K1^v1+w2*K2^v2))
  dk1=sum(A*postcode.YY*K1^v1)
  dk2=sum(A*postcode.YY*K2^v2)
  dk3=w1*sum(A*postcode.YY*K1^v1*log(K1))
  dk4=w2*sum(A*postcode.YY*K2^v2*log(K2))
  grad=c(dk1,dk2,dk3,dk4)
  return(list("objective"=f, "gradient"=grad))
}                                                                                                                                                                                                                                                                                                                       
eval_g_eq <- function(w){
  constr <-c(w[1]+w[2]-1)
  grad=c(1,1,1,1)
  return(list("constraints"=constr,
              "jacobian"=grad))
}

local_opts <- list( "algorithm" = "NLOPT_LD_MMA",
                    "xtol_rel"  = 1.0e-7 )
opts <- list( "algorithm" = "NLOPT_LD_AUGLAG",
              "xtol_rel"  = 1.0e-7,
              "maxeval"   = 10000,
              "local_opts" = local_opts )

timex0=20
a1=runif(timex0,min=0,max=1)
a2=1-a1
a3=runif(timex0,min=0,max=1)
a4=runif(timex0,min=0,max=1)
optim_result=NULL
for(ii in 1:timex0){
  result=nloptr(x0=c(a1[ii],a2[ii],a3[ii],a4[ii]),eval_f=ff,
                lb=c(0,0,0,0),ub=c(1,1,10,10),
                eval_g_eq=eval_g_eq,opts = opts)
  obj_fun=result$objective
  a=c(result$solution,obj_fun)
  optim_result=rbind(optim_result,a)
}
colnames(optim_result)=c("w1","w2","v1","v2","objfunvalue")
optim_result=as.data.frame(optim_result)
optires_arrange=dplyr::arrange(optim_result,objfunvalue)

#comparison experiment based different kernel
#custom definiting kernl function
tkernel=function(x,y,w1=0.86,w2=0.14,p1=2,p2=2.5){
  dist1=(sum(abs(x-y)^p1))^(1/p1)
  dist2=(sum(abs(x-y)^p2))^(1/p2)
  v1=0.9;v2=1
  f1=(1/(1+dist1))^v1;f2=(1/(1+dist2))^v2
  wf=w1*f1+w2*f2
  return(wf)
}
class(tkernel)="kernel"
#k fold cross-validation
#setseed=12 123 1234 12345 123456
setseed=12
CV<-function(data=w,Z,seed=setseed){
  set.seed(seed)
  n=nrow(data);N=1:n
  mm=sample(rep(1:Z,ceiling(n/Z))[N])
  K=list()
  for(i in 1:Z) K[[i]]=N[mm==i]
  return(K)
}
k=5
mm=CV(postcode1,k)
options(digits=4)
#svm based p-norm t kernel evaluation
postcode.acc<-NULL;postcode.recall=NULL;postcode.kappa=NULL
for (i in 1:k){
  svm_tkernel<-ksvm(class~.,data=postcode1[-mm[[i]],],
                    kernel=tkernel)
  pred.svm<-predict(svm_tkernel,newdata=postcode1[mm[[i]],])
  aa<-table(postcode1[mm[[i]],]$class,pred.svm)
  acc<-(sum(diag(aa)))/sum(aa)
  recall<-(aa[1,1])/sum(aa[1,])
  pe=sum(colSums(aa)*rowSums(aa))/sum(aa)^2
  kappa=(acc-pe)/(1-pe)
  postcode.acc<-c(postcode.acc,acc)
  postcode.recall<-c(postcode.acc,recall)
  postcode.kappa<-c(postcode.kappa,kappa)
}
(postcode_meanacc_tkernel<-mean(postcode.acc))
(postcode_meanrecall_tkernel<-mean(postcode.recall))
(postcode_meankappa_tkernel<-mean(postcode.kappa))
tkern=c(postcode_meanacc_tkernel,postcode_meanrecall_tkernel,
        postcode_meankappa_tkernel)
#svm based rbfkernel evaluation
postcode.acc<-NULL;postcode.recall=NULL;postcode.kappa=NULL
for (i in 1:k){
  svm_tkernel<-ksvm(class~.,data=postcode1[-mm[[i]],],
                    kernel="rbfdot",kpar=list(sigma=0.015))
  pred.svm<-predict(svm_tkernel,newdata=postcode1[mm[[i]],])
  aa<-table(postcode1[mm[[i]],]$class,pred.svm)
  acc<-(sum(diag(aa)))/sum(aa)
  recall<-(aa[1,1])/sum(aa[1,])
  pe=sum(colSums(aa)*rowSums(aa))/sum(aa)^2
  kappa=(acc-pe)/(1-pe)
  postcode.acc<-c(postcode.acc,acc)
  postcode.recall<-c(postcode.acc,recall)
  postcode.kappa<-c(postcode.kappa,kappa)
}
(postcode_meanacc_rbf<-mean(postcode.acc))
(postcode_meanrecall_rbf<-mean(postcode.recall))
(postcode_meankappa_rbf<-mean(postcode.kappa))
rbf=c(postcode_meanacc_rbf,postcode_meanrecall_rbf,
      postcode_meankappa_rbf)
#svm based ploykernel evaluation
postcode.acc<-NULL;postcode.recall=NULL;postcode.kappa=NULL
for (i in 1:k){
  svm_poly<-ksvm(class~.,data=postcode1[-mm[[i]],],
                 kernel="polydot",
                 kpar=list(degree=2))
  pred.svm<-predict(svm_poly,newdata=postcode1[mm[[i]],])
  aa<-table(postcode1[mm[[i]],]$class,pred.svm)
  acc<-(sum(diag(aa)))/sum(aa)
  recall<-(aa[1,1])/sum(aa[1,])
  pe=sum(colSums(aa)*rowSums(aa))/sum(aa)^2
  kappa=(acc-pe)/(1-pe)
  postcode.acc<-c(postcode.acc,acc)
  postcode.recall<-c(postcode.acc,recall)
  postcode.kappa<-c(postcode.kappa,kappa)
}
(postcode_meanacc_poly<-mean(postcode.acc))
(postcode_meanrecall_poly<-mean(postcode.recall))
(postcode_meankappa_poly<-mean(postcode.kappa))
poly=c(postcode_meanacc_poly,postcode_meanrecall_poly,
       postcode_meankappa_poly)
#svm based sigmoidkernel evaluation
postcode.acc<-NULL;postcode.recall=NULL;postcode.kappa=NULL
for (i in 1:k){
  svm_sigmoid<-ksvm(class~.,data=postcode1[-mm[[i]],],
                    kernel="tanhdot",
                    kpar=list(scale=1,offset=-1))
  pred.svm<-predict(svm_sigmoid,newdata=postcode1[mm[[i]],])
  aa<-table(postcode1[mm[[i]],]$class,pred.svm)
  acc<-(sum(diag(aa)))/sum(aa)
  recall<-(aa[1,1])/sum(aa[1,])
  pe=sum(colSums(aa)*rowSums(aa))/sum(aa)^2
  kappa=(acc-pe)/(1-pe)
  postcode.acc<-c(postcode.acc,acc)
  postcode.recall<-c(postcode.acc,recall)
  postcode.kappa<-c(postcode.kappa,kappa)
}
(postcode_meanacc_sigmoid<-mean(postcode.acc))
(postcode_meanrecall_sigmoid<-mean(postcode.recall))
(postcode_meankappa_sigmoid<-mean(postcode.kappa))
sigmoid=c(postcode_meanacc_sigmoid,postcode_meanrecall_sigmoid,
          postcode_meankappa_sigmoid)
#svm based Laplacian kernel evaluation
postcode.acc<-NULL;postcode.recall=NULL;postcode.kappa=NULL
for (i in 1:k){
  svm_lap<-ksvm(class~.,data=postcode1[-mm[[i]],],
                kernel="laplacedot",
                kpar=list(sigma=0.05))
  pred.svm<-predict(svm_lap,newdata=postcode1[mm[[i]],])
  aa<-table(postcode1[mm[[i]],]$class,pred.svm)
  acc<-(sum(diag(aa)))/sum(aa)
  recall<-(aa[1,1])/sum(aa[1,])
  pe=sum(colSums(aa)*rowSums(aa))/sum(aa)^2
  kappa=(acc-pe)/(1-pe)
  postcode.acc<-c(postcode.acc,acc)
  postcode.recall<-c(postcode.acc,recall)
  postcode.kappa<-c(postcode.kappa,kappa)
}
(postcode_meanacc_lap<-mean(postcode.acc))
(postcode_meanrecall_lap<-mean(postcode.recall))
(postcode_meankappa_lap<-mean(postcode.kappa))
lap=c(postcode_meanacc_lap,postcode_meanrecall_lap,
      postcode_meankappa_lap)
#svm based Linear kernel evaluation
postcode.acc<-NULL;postcode.recall=NULL;postcode.kappa=NULL
for (i in 1:k){
  svm_linear<-ksvm(class~.,data=postcode1[-mm[[i]],],
                   kernel="vanilladot",
                   kpar=list())
  pred.svm<-predict(svm_linear,newdata=postcode1[mm[[i]],])
  aa<-table(postcode1[mm[[i]],]$class,pred.svm)
  acc<-(sum(diag(aa)))/sum(aa)
  recall<-(aa[1,1])/sum(aa[1,])
  pe=sum(colSums(aa)*rowSums(aa))/sum(aa)^2
  kappa=(acc-pe)/(1-pe)
  postcode.acc<-c(postcode.acc,acc)
  postcode.recall<-c(postcode.acc,recall)
  postcode.kappa<-c(postcode.kappa,kappa)
}
(postcode_meanacc_linear<-mean(postcode.acc))
(postcode_meanrecall_linear<-mean(postcode.recall))
(postcode_meankappa_linear<-mean(postcode.kappa))
linear=c(postcode_meanacc_linear,postcode_meanrecall_linear,
         postcode_meankappa_linear)
result_postcode=data.frame(poly,sigmoid,rbf,lap,linear,tkern)
rownames(result_postcode)=c("accuracy","recall","kappa")
